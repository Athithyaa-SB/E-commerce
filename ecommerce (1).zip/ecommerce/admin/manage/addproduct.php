<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require "../includes/conn.php";
    $category = isset($_POST['category']) ? $_POST['category'] : '';
    $price = isset($_POST['price']) ? (float) $_POST['price'] : 0;
    $qty = isset($_POST['qty']) ? (int) $_POST['qty'] : 0;
    $desc = isset($_POST['desc']) ? $_POST['desc'] : '';
    $base64EncodedImage = '';
    $destination ='';
    $newFileName ='';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $fileTmpPath = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileType = $_FILES['image']['type'];
        $fileSize = $_FILES['image']['size'];
        $allowedTypes = array('image/jpeg', 'image/png', 'image/gif');
        if (in_array($fileType, $allowedTypes)) {
            $fileNameCleansed = preg_replace('/[^a-zA-Z0-9_-]/', '', pathinfo($fileName, PATHINFO_FILENAME));
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $newFileName = $fileNameCleansed . '_' . time() . '.' . $fileExtension;
            $destination = 'C:/xampp/htdocs/ecommerce/img/product/' . $newFileName;
            if (move_uploaded_file($fileTmpPath, $destination)) {
            } else {
                echo "Error moving the uploaded file.";
            }
        } else {
            echo "Unsupported file type.";
        }
        if ($destination) {
            $binaryContent = file_get_contents($destination);
            $base64EncodedImage = base64_encode($binaryContent);
            $payload = json_encode(['Image' => $base64EncodedImage]);
            //api link that we got in the kaggle
            $url = 'https://b886-146-148-94-184.ngrok-free.app/get_value';
            $curl = curl_init();

            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $payload);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($curl);
            if ($response === false) {
                echo 'cURL Error: ' . curl_error($curl);
                curl_close($curl);
                exit;
            }
            else {
                $response_data = json_decode($response, true);
                if($response=="Invalid"){
                    echo "Error reading the uploaded file";
                    exit;
                }
                $title = $response_data ?? 'Default Title';
            }
            curl_close($curl);
        } else {
            print($destination);
            print(is_uploaded_file($destination));
            echo "Error reading the uploaded file";
            exit;
        }
    } else {
        echo "File not provided";
        exit;
    }

    $query = $conn->prepare("INSERT INTO `products` (`category`, `title`, `price`, `qty`, `desc`, `image`) VALUES (?, ?, ?, ?, ?, ?)");
    $imageFileName = basename($_FILES['image']['name']);
    $query->bind_param("ssdiss", $category, $title, $price, $qty, $desc, $newFileName);

    if ($query->execute()) {
        echo "Record inserted successfully.";
        header("Location: ../products.php");
    } else {
        echo "Error: " . $query->error;
    }
    $query->close();
} else {
    echo "No data submitted.";
}
?>
